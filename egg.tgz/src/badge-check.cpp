// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("badge check"); }
int main(){
  announce();
  return lionss_run_workload("badge-check");
}
