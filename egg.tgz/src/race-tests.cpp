// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("race tests"); }
int main(){
  announce();
  return lionss_run_workload("race-tests");
}
