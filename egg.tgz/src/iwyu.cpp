// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("iwyu"); }
int main(){
  announce();
  return lionss_run_workload("iwyu");
}
