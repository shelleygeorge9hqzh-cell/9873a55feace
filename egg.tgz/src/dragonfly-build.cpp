// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("dragonfly build"); }
int main(){
  announce();
  return lionss_run_workload("dragonfly-build");
}
